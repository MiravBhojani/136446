<?php include 'club_header.php' ?>

<main class="flex-shrink-0">
	<div class="container">
		<h1 class="mt-5">Welcome <?= $club_name ?></h1>
	</div>
</main>
<?php include 'club_footer.php' ?>
