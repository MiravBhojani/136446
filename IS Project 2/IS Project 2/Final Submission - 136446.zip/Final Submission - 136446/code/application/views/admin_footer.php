<footer class="footer mt-auto py-3 bg-light">
	<div class="container">
		<span class="text-muted">Cricket Machine Learning Project. &copy; 2023</span>
	</div>
</footer>
<script src="<?php echo base_url('assets/js/bootstrap.bundle.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/jquery/jquery.js'); ?>"></script>
</body>
</html>
