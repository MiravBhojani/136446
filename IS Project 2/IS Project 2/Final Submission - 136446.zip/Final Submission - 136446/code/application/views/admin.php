<?php include 'admin_header.php'; ?>
<main class="flex-shrink-0">
	<div class="container">
		<h1 class="mt-5">Welcome Admin</h1>
		<!--			<p>-->
		<!--				Added This section-->
		<!--			</p>-->
	</div>
</main>
<?php include 'admin_footer.php'; ?>
