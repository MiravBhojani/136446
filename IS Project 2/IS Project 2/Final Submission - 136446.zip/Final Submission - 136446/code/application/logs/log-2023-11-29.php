<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-29 08:41:33 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\cai\application\controllers\Welcome.php 21
ERROR - 2023-11-29 08:48:44 --> Match ID = 11
ERROR - 2023-11-29 08:52:06 --> Match ID = 12
ERROR - 2023-11-29 08:58:32 --> Match ID = 13
ERROR - 2023-11-29 09:01:28 --> Match ID = 14
ERROR - 2023-11-29 09:05:40 --> Match ID = 15
ERROR - 2023-11-29 09:08:26 --> Match ID = 16
ERROR - 2023-11-29 09:11:03 --> Match ID = 17
