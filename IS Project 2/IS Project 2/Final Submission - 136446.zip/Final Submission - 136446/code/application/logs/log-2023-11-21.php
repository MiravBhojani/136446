ERROR - 2023-11-21 12:57:05 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\cai\application\controllers\Welcome.php 21
