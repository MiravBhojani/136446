<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-30 08:53:18 --> Query error: MySQL server has gone away - Invalid query: SELECT `users`.*, `users`.`id` as `id`, `users`.`id` as `user_id`
FROM `users`
WHERE `email` = 'mirav.bhojani@strathmore.edu'
ERROR - 2023-11-30 08:53:18 --> Severity: error --> Exception: Call to a member function row() on bool C:\xampp\htdocs\cai\application\models\Ion_auth_model.php 1324
ERROR - 2023-11-30 08:53:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\xampp\htdocs\cai\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-11-30 08:53:25 --> Unable to connect to the database
ERROR - 2023-11-30 08:58:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\xampp\htdocs\cai\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-11-30 08:58:15 --> Unable to connect to the database
ERROR - 2023-11-30 08:58:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\xampp\htdocs\cai\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-11-30 08:58:19 --> Unable to connect to the database
ERROR - 2023-11-30 08:58:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\xampp\htdocs\cai\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-11-30 08:58:30 --> Unable to connect to the database
ERROR - 2023-11-30 08:58:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\xampp\htdocs\cai\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-11-30 08:58:34 --> Unable to connect to the database
ERROR - 2023-11-30 11:03:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\xampp\htdocs\cai\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-11-30 11:03:31 --> Unable to connect to the database
ERROR - 2023-11-30 11:03:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\xampp\htdocs\cai\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-11-30 11:03:36 --> Unable to connect to the database
ERROR - 2023-11-30 11:03:36 --> Query error: No connection could be made because the target machine actively refused it - Invalid query: SELECT `users`.*, `users`.`id` as `id`, `users`.`id` as `user_id`
FROM `users`
WHERE `users`.`id` IS NULL
ORDER BY `users`.`id` DESC
 LIMIT 1
ERROR - 2023-11-30 11:03:36 --> Severity: error --> Exception: Call to a member function row() on bool C:\xampp\htdocs\cai\application\models\Ion_auth_model.php 1324
ERROR - 2023-11-30 11:03:54 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\cai\application\controllers\Welcome.php 21
ERROR - 2023-11-30 11:04:47 --> Severity: Warning --> Undefined variable $existingClub C:\xampp\htdocs\cai\application\controllers\Welcome.php 1077
ERROR - 2023-11-30 11:08:55 --> Severity: Warning --> Undefined variable $existingClub C:\xampp\htdocs\cai\application\controllers\Welcome.php 1077
ERROR - 2023-11-30 14:04:01 --> Match ID = 18
ERROR - 2023-11-30 14:15:02 --> 404 Page Not Found: Assets/css
ERROR - 2023-11-30 14:15:02 --> 404 Page Not Found: Assets/js
ERROR - 2023-11-30 17:43:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\xampp\htdocs\cai\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-11-30 17:43:47 --> Unable to connect to the database
ERROR - 2023-11-30 17:43:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\xampp\htdocs\cai\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-11-30 17:43:52 --> Unable to connect to the database
ERROR - 2023-11-30 17:43:52 --> Query error: No connection could be made because the target machine actively refused it - Invalid query: SELECT `users`.*, `users`.`id` as `id`, `users`.`id` as `user_id`
FROM `users`
WHERE `users`.`id` IS NULL
ORDER BY `users`.`id` DESC
 LIMIT 1
ERROR - 2023-11-30 17:43:52 --> Severity: error --> Exception: Call to a member function row() on bool C:\xampp\htdocs\cai\application\models\Ion_auth_model.php 1324
ERROR - 2023-11-30 17:43:57 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\cai\application\controllers\Welcome.php 21
ERROR - 2023-11-30 17:44:41 --> Severity: Warning --> Undefined variable $existingClub C:\xampp\htdocs\cai\application\controllers\Welcome.php 1077
ERROR - 2023-11-30 17:46:20 --> Severity: Warning --> Undefined variable $existingClub C:\xampp\htdocs\cai\application\controllers\Welcome.php 1077
ERROR - 2023-11-30 17:50:51 --> Match ID = 19
