<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-24 09:42:08 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\cai\application\controllers\Welcome.php 21
ERROR - 2023-11-24 09:45:03 --> Query error: Unknown column 'Name' in 'field list' - Invalid query: SELECT `Name`, `matches`, `oversbowled`, `bowls`, `runsgiven`, `wicketstaken`, `economy`, `performancewickets5`, `performancewickets4`, `performancewickets3`, `performancewickets2`, `performancewickets1`
FROM `bowlingreport`
ORDER BY `wicketstaken` desc
 LIMIT 10
ERROR - 2023-11-24 09:45:03 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\xampp\htdocs\cai\application\controllers\Welcome.php 132
ERROR - 2023-11-24 09:45:08 --> Query error: Unknown column 'Name' in 'field list' - Invalid query: SELECT `Name`, `matches`, `oversbowled`, `bowls`, `runsgiven`, `wicketstaken`, `economy`, `performancewickets5`, `performancewickets4`, `performancewickets3`, `performancewickets2`, `performancewickets1`
FROM `bowlingreport`
ORDER BY `wicketstaken` desc
 LIMIT 10
ERROR - 2023-11-24 09:45:08 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\xampp\htdocs\cai\application\controllers\Welcome.php 132
ERROR - 2023-11-24 09:45:16 --> Query error: Unknown column 'Name' in 'field list' - Invalid query: SELECT `Name`, `matches`, `oversbowled`, `bowls`, `runsgiven`, `wicketstaken`, `economy`, `performancewickets5`, `performancewickets4`, `performancewickets3`, `performancewickets2`, `performancewickets1`
FROM `bowlingreport`
ORDER BY `wicketstaken` desc
 LIMIT 10
ERROR - 2023-11-24 09:45:16 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\xampp\htdocs\cai\application\controllers\Welcome.php 132
ERROR - 2023-11-24 09:45:29 --> Query error: Unknown column 'Name' in 'field list' - Invalid query: SELECT `Name`, `matches`, `oversbowled`, `bowls`, `runsgiven`, `wicketstaken`, `economy`, `performancewickets5`, `performancewickets4`, `performancewickets3`, `performancewickets2`, `performancewickets1`
FROM `bowlingreport`
ORDER BY `wicketstaken` desc
 LIMIT 10
ERROR - 2023-11-24 09:45:29 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\xampp\htdocs\cai\application\controllers\Welcome.php 132
ERROR - 2023-11-24 09:45:32 --> Query error: Unknown column 'Name' in 'field list' - Invalid query: SELECT `Name`, `matches`, `oversbowled`, `bowls`, `runsgiven`, `wicketstaken`, `economy`, `performancewickets5`, `performancewickets4`, `performancewickets3`, `performancewickets2`, `performancewickets1`
FROM `bowlingreport`
ORDER BY `wicketstaken` desc
 LIMIT 10
ERROR - 2023-11-24 09:45:32 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\xampp\htdocs\cai\application\controllers\Welcome.php 132
ERROR - 2023-11-24 09:59:41 --> Query error: Unknown column 'Name' in 'field list' - Invalid query: SELECT `Name`, `matches`, `oversbowled`, `bowls`, `runsgiven`, `wicketstaken`, `economy`, `performancewickets5`, `performancewickets4`, `performancewickets3`, `performancewickets2`, `performancewickets1`
FROM `bowlingreport`
ORDER BY `wicketstaken` desc
 LIMIT 10
ERROR - 2023-11-24 09:59:41 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\xampp\htdocs\cai\application\controllers\Welcome.php 132
ERROR - 2023-11-24 10:02:28 --> Query error: Unknown column 'Name' in 'field list' - Invalid query: SELECT `Name`, `matches`, `oversbowled`, `bowls`, `runsgiven`, `wicketstaken`, `economy`, `performancewickets5`, `performancewickets4`, `performancewickets3`, `performancewickets2`, `performancewickets1`
FROM `bowlingreport`
ORDER BY `wicketstaken` desc
 LIMIT 10
ERROR - 2023-11-24 10:02:28 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\xampp\htdocs\cai\application\controllers\Welcome.php 132
ERROR - 2023-11-24 10:02:37 --> Query error: Unknown column 'Name' in 'field list' - Invalid query: SELECT `Name`, `matches`, `oversbowled`, `bowls`, `runsgiven`, `wicketstaken`, `economy`, `performancewickets5`, `performancewickets4`, `performancewickets3`, `performancewickets2`, `performancewickets1`
FROM `bowlingreport`
ORDER BY `wicketstaken` desc
 LIMIT 10
ERROR - 2023-11-24 10:02:37 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\xampp\htdocs\cai\application\controllers\Welcome.php 132
ERROR - 2023-11-24 10:50:40 --> Query error: Unknown column 'Name' in 'field list' - Invalid query: SELECT `Name`, `matches`, `oversbowled`, `bowls`, `runsgiven`, `wicketstaken`, `economy`, `performancewickets5`, `performancewickets4`, `performancewickets3`, `performancewickets2`, `performancewickets1`
FROM `bowlingreport`
ORDER BY `wicketstaken` desc
 LIMIT 10
ERROR - 2023-11-24 10:50:40 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\xampp\htdocs\cai\application\controllers\Welcome.php 132
ERROR - 2023-11-24 13:13:17 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\cai\application\controllers\Welcome.php 21
ERROR - 2023-11-24 13:13:19 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\cai\application\controllers\Welcome.php 21
