<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-01 07:08:26 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\cai\application\controllers\Welcome.php 21
ERROR - 2023-12-01 07:08:26 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\cai\application\controllers\Welcome.php 21
ERROR - 2023-12-01 10:49:34 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\cai\application\controllers\Welcome.php 21
ERROR - 2023-12-01 12:20:06 --> Severity: Warning --> Undefined variable $existingClub C:\xampp\htdocs\cai\application\controllers\Welcome.php 1077
ERROR - 2023-12-01 12:24:07 --> Match ID = 20
