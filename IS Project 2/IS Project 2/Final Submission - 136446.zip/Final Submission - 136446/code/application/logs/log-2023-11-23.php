<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-23 09:10:15 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\cai\application\controllers\Welcome.php 21
