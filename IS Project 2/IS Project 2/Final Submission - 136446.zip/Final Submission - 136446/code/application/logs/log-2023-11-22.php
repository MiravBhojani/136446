<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-22 06:59:19 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\cai\application\controllers\Welcome.php 21
ERROR - 2023-11-22 06:59:30 --> 404 Page Not Found: Assets/css
ERROR - 2023-11-22 06:59:31 --> 404 Page Not Found: Assets/js
